module.exports = {
  // URL: 'mongodb://localhost/donatbookDB',

  GCM_API_KEY: "AAAAX7mkRqc:APA91bE764eoPwz9ExHT4em7GrlG2BqnnMI2gSpSyp0l6m0pgxkcILxe5Zrz5a6tSSw5piHY3gLGhl_DbKjtAg524mFL-8uhY1NhWCLys5wxR1Nb7wdQ5Qbgoxz7WPX4PBa022rJqssR",


};